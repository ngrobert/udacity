--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS;
CREATE ROLE rng;
ALTER ROLE rng WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN NOREPLICATION NOBYPASSRLS;






--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

-- Dumped from database version 12.1
-- Dumped by pg_dump version 12.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- Database "example" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 12.1
-- Dumped by pg_dump version 12.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: example; Type: DATABASE; Schema: -; Owner: rng
--

CREATE DATABASE example WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE example OWNER TO rng;

\connect example

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: persons; Type: TABLE; Schema: public; Owner: rng
--

CREATE TABLE public.persons (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.persons OWNER TO rng;

--
-- Name: persons_id_seq; Type: SEQUENCE; Schema: public; Owner: rng
--

CREATE SEQUENCE public.persons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.persons_id_seq OWNER TO rng;

--
-- Name: persons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rng
--

ALTER SEQUENCE public.persons_id_seq OWNED BY public.persons.id;


--
-- Name: persons id; Type: DEFAULT; Schema: public; Owner: rng
--

ALTER TABLE ONLY public.persons ALTER COLUMN id SET DEFAULT nextval('public.persons_id_seq'::regclass);


--
-- Data for Name: persons; Type: TABLE DATA; Schema: public; Owner: rng
--

COPY public.persons (id, name) FROM stdin;
1	Amy
2	Sara
\.


--
-- Name: persons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rng
--

SELECT pg_catalog.setval('public.persons_id_seq', 2, true);


--
-- Name: persons persons_pkey; Type: CONSTRAINT; Schema: public; Owner: rng
--

ALTER TABLE ONLY public.persons
    ADD CONSTRAINT persons_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

-- Dumped from database version 12.1
-- Dumped by pg_dump version 12.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- Database "rng" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 12.1
-- Dumped by pg_dump version 12.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: rng; Type: DATABASE; Schema: -; Owner: rng
--

CREATE DATABASE rng WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE rng OWNER TO rng;

\connect rng

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- Database "todoapp" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 12.1
-- Dumped by pg_dump version 12.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: todoapp; Type: DATABASE; Schema: -; Owner: rng
--

CREATE DATABASE todoapp WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE todoapp OWNER TO rng;

\connect todoapp

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: rng
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO rng;

--
-- Name: todolists; Type: TABLE; Schema: public; Owner: rng
--

CREATE TABLE public.todolists (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.todolists OWNER TO rng;

--
-- Name: todolists_id_seq; Type: SEQUENCE; Schema: public; Owner: rng
--

CREATE SEQUENCE public.todolists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.todolists_id_seq OWNER TO rng;

--
-- Name: todolists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rng
--

ALTER SEQUENCE public.todolists_id_seq OWNED BY public.todolists.id;


--
-- Name: todos; Type: TABLE; Schema: public; Owner: rng
--

CREATE TABLE public.todos (
    id integer NOT NULL,
    description character varying NOT NULL,
    completed boolean NOT NULL,
    list_id integer NOT NULL
);


ALTER TABLE public.todos OWNER TO rng;

--
-- Name: todos_id_seq; Type: SEQUENCE; Schema: public; Owner: rng
--

CREATE SEQUENCE public.todos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.todos_id_seq OWNER TO rng;

--
-- Name: todos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rng
--

ALTER SEQUENCE public.todos_id_seq OWNED BY public.todos.id;


--
-- Name: todolists id; Type: DEFAULT; Schema: public; Owner: rng
--

ALTER TABLE ONLY public.todolists ALTER COLUMN id SET DEFAULT nextval('public.todolists_id_seq'::regclass);


--
-- Name: todos id; Type: DEFAULT; Schema: public; Owner: rng
--

ALTER TABLE ONLY public.todos ALTER COLUMN id SET DEFAULT nextval('public.todos_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: rng
--

COPY public.alembic_version (version_num) FROM stdin;
e51af9a802fd
\.


--
-- Data for Name: todolists; Type: TABLE DATA; Schema: public; Owner: rng
--

COPY public.todolists (id, name) FROM stdin;
1	uncategorized
2	Urgent
\.


--
-- Data for Name: todos; Type: TABLE DATA; Schema: public; Owner: rng
--

COPY public.todos (id, description, completed, list_id) FROM stdin;
9	sadf	f	1
8	asdfasfdafsaf	t	1
10	asdf	t	1
13	asfs	f	1
15	This is important	f	2
16	This is important 2	f	2
\.


--
-- Name: todolists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rng
--

SELECT pg_catalog.setval('public.todolists_id_seq', 2, true);


--
-- Name: todos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rng
--

SELECT pg_catalog.setval('public.todos_id_seq', 44, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: rng
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: todolists todolists_pkey; Type: CONSTRAINT; Schema: public; Owner: rng
--

ALTER TABLE ONLY public.todolists
    ADD CONSTRAINT todolists_pkey PRIMARY KEY (id);


--
-- Name: todos todos_pkey; Type: CONSTRAINT; Schema: public; Owner: rng
--

ALTER TABLE ONLY public.todos
    ADD CONSTRAINT todos_pkey PRIMARY KEY (id);


--
-- Name: todos todos_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rng
--

ALTER TABLE ONLY public.todos
    ADD CONSTRAINT todos_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.todolists(id);


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--

